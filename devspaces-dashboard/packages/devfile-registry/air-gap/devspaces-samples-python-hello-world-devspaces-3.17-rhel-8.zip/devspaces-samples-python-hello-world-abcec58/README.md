# python-hello-world

A simple program that displays “Hello, World!”. It's often used to illustrate the syntax of the language.
