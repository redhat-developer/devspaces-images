# -------------------------------------------------------------
#  Copyright (c) 2022 Red Hat, Inc. All rights reserved.
#  Licensed under the MIT License. See LICENSE in project root.
# -------------------------------------------------------------
# Sample tests to show how the UI works
# you must enable/install pytest or some other testing
# framework for this to work.

def test_pytest_1():
    assert True


def test_pytest_2():
    assert False
