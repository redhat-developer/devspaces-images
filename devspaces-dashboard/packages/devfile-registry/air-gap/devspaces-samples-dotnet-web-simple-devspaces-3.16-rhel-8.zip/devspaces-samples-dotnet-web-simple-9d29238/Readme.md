# dotnet-web-simple application

It is a simple dotnet web application which uses `net8.0` as a target framework.

 
# Application Output

The app will print `Hello World!`
