package org.acme.ssm;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class SsmResourcesIT extends SsmResourcesTest {
    // Runs the same tests as the parent class
}
