package org.acme.getting.started.async;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class GreetingResourceIT extends GreetingResourceTest {

    // Execute the same tests but in native mode.
}