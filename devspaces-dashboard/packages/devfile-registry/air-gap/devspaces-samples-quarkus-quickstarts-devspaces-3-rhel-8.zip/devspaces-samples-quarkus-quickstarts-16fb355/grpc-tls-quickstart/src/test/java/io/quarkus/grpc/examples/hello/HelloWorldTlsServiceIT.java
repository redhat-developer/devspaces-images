package io.quarkus.grpc.examples.hello;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
class HelloWorldTlsServiceIT extends HelloWorldTlsEndpointTest {

}