Quarkus guide: https://quarkus.io/guides/funqy-amazon-lambda
