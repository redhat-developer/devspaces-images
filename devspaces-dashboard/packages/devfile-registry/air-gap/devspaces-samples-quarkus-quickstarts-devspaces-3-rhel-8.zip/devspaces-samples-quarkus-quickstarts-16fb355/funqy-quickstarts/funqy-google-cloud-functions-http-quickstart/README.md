Quarkus guide: https://quarkus.io/guides/funqy-google-cloud-functions-http
