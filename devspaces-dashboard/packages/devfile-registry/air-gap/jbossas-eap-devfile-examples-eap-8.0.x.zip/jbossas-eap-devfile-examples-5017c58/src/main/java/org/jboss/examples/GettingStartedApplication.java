package org.jboss.examples;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/hello")
public class GettingStartedApplication extends Application {

}
